export const ReleaseNotesUri = 'https://desktop.github.com/release-notes/'
