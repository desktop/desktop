package com.yili.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.yili.bean.ParamSearch;
import com.yili.bean.ResultData;
import com.yili.services.IShortService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

@Controller
@RequestMapping("/manage/short")
@Api(tags = "短域名接口")
public class ShortController {

	@Autowired
	private IShortService shortService;

	/**
	 * 生成域名
	 * 
	 * @param 条件
	 * @return 记录条数
	 */
	 @ApiOperation(value = "生成短域名", notes = "短域名")
	    @ApiImplicitParam(name = "param", value = "ParamSearch实体 keyWord URL地址，例如 keyWord=https://www.web3.xin/code/3007.html", required = true,
	        dataType = "ParamSearch")
	@RequestMapping(value = "getShortDomain", method = RequestMethod.POST)
	@ResponseBody
	public ResultData<String> getShortDomain(@RequestBody ParamSearch param) {
		return shortService.getShortDomain(param);
	}
	/**
	 * 跳转域名
	 * 
	 * @param 条件
	 * @return 记录条数
	 */
	 @ApiOperation(value = "通过短域名跳转到实际地址", notes = "跳转地址")
	    @ApiImplicitParam(name = "id", value = "id 短域名关键字符串，短域名：BzQfamaa（http://localhost/manage/short/BzQfamaa） ", required = true,
	        dataType = "String")
	@RequestMapping(value = "{id}", method = RequestMethod.GET)
	public ModelAndView getShortDomain(@PathVariable String id,HttpServletResponse response) {
		ResultData<String> dom = shortService.getDomainUrl(id);
		return  new ModelAndView(new RedirectView(dom.getData())); 
	}
}
