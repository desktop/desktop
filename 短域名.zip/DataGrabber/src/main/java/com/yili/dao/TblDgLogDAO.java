package com.yili.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.yili.bean.ParamSearch;
import com.yili.entity.TblDgLog;

/**
 * TblDgLogDAO继承基类
 */
@Repository
public interface TblDgLogDAO extends MyBatisBaseDao<TblDgLog, Integer> {
	/**
	 * 分页查询
	 * 
	 * @param 条件
	 * @return 记录条数
	 */
	List<TblDgLog> searchPager(ParamSearch param);

	/**
	 * 分页查询记录条数
	 * 
	 * @param 条件
	 * @return 记录条数
	 */
	int searchPagerCount(ParamSearch param);
}