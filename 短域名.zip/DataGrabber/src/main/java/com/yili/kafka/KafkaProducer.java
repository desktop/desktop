package com.yili.kafka;


import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;


@Component
public class KafkaProducer {
	private static Logger LOG = LoggerFactory.getLogger(CustomPartitioner.class);

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	/**
	 * 通过配置文件中读取默认主题，当主题参数为空时使用这个
	 */
	@Value("${spring.kafka.topic}")
	private String defaultTopic;
	public void sendMessage(String topic,String message) {
		if(StringUtils.isBlank(topic)) {
			topic=defaultTopic;
		}
		kafkaTemplate.send(topic,message);
	}
}
