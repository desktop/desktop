package com.yili.services.impl;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.yili.bean.ParamSearch;
import com.yili.bean.ResultData;
import com.yili.services.IShortService;
import com.yili.utils.CMyEncrypt;

@Service
public class ShortServiceImpl implements IShortService {

	private static Logger log = LoggerFactory.getLogger(ShortServiceImpl.class);
	/**
	 * 不应该把短服务域名存在这，应该存redis或数据库
	 */
	private static volatile  Hashtable table = null;
	public Hashtable getCache() {
		if(table == null) {
			synchronized(this) {
				if(table == null) {table = new Hashtable(); }
			}
		}
		return table;
	}
	/**
	 * 生成短域名
	 * String sLongUrl = "https://zhangvalue.blog.csdn.net/"; // 长链接
	 * @param 条件
	 * @return 记录条数
	 */
	@Override
	public ResultData<String> getShortDomain(ParamSearch param) {
		ResultData<String> result = new ResultData<String>();
		result.setCode(0);
		
		try {
			
			if (param == null || param.getKeyWord() == null ||  param.getKeyWord().equals("")) {
				result.setMessage("参数错误");
				return result;
			}
			 
		    String[] data = shortUrl(param.getKeyWord());
		    
		    Hashtable cache = getCache();
		    
		    if(!cache.containsValue(param.getKeyWord())) {
			    cache.put(data[0], param.getKeyWord());
		    }
		    result.setData(data[0]);
			result.setCode(1);
			result.setMessage("操作成功");
			return result;

		} catch (Exception e) {
			log.error("查询异常:" + param == null ? "" : JSONObject.toJSONString(param), e);
		}
		result.setMessage("操作错误");
		return result;
	}
	/**
	 * 返回真实域名
	 * 
	 * @key 条件
	 * @return 记录条数
	 */
	@Override
	public ResultData<String> getDomainUrl(String key) {
		ResultData<String> result = new ResultData<String>();
		result.setCode(0);
		
		try {
			
			if (key == null ||key.equals("")) {
				result.setMessage("参数错误");
				return result;
			}
			 Hashtable cache = getCache();
			 
			 if(cache.containsKey(key)) {
			    result.setData(cache.get(key).toString());
				result.setCode(1);
				result.setMessage("操作成功");
			 }
			 else {
				 result.setMessage("未找到短服务域名");
			 }
			return result;

		} catch (Exception e) {
			log.error("查询异常:" + key == null ? "" : key, e);
		}
		result.setMessage("操作错误");
		return result;
	}
	
	 public static String[] shortUrl(String url) {
		 
	        // 要使用生成 URL 的字符
	        String[] chars = new String[] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p",
	                "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A",
	                "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V",
	                "W", "X", "Y", "Z"
	        };
	 
	        String key = "mimvp.com";                               // 可以自定义生成 MD5 加密字符传前的混合加密key
	        String sMD5EncryptResult = CMyEncrypt.md5(key + url);       // 对传入网址进行 MD5 加密，key是加密字符串
	        String hex = sMD5EncryptResult;
	 
	        String[] resUrl = new String[4];
	        for (int i = 0; i < 4; i++) {
	            // 把加密字符按照8位一组16进制与0x3FFFFFFF进行位与运算
	            String sTempSubString = hex.substring(i * 8, i * 8 + 8);
	 
	            // 这里需要使用 long 型来转换，因为 Inteter.parseInt() 只能处理 31 位 , 首位为符号位 , 如果不用 long ，则会越界
	            long lHexLong = 0x3FFFFFFF & Long.parseLong(sTempSubString, 16);
	            String outChars = "";
	            for (int j = 0; j < 8; j++) {
	                long index = 0x0000003D & lHexLong;     // 把得到的值与 0x0000003D 进行位与运算，取得字符数组 chars 索引
	                outChars += chars[(int) index];         // 把取得的字符相加
	                lHexLong = lHexLong >> 5;             // 每次循环按位右移 5 位
	            }
	            resUrl[i] = outChars;                       // 把字符串存入对应索引的输出数组
	        }
	        return resUrl;
	    }
}
