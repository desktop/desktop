package com.yili.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.function.Function;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.yili.kafka.CustomPartitioner;

/**
 * 下载文件
 * 
 * @author user
 *
 */
@Component
public class DownloadFile {
	private static Logger LOG = LoggerFactory.getLogger(CustomPartitioner.class);
	/**
	 * 文件存储目录
	 */
	@Value("${spring.image.destPath}")
	private String destPath;
	/**
	 * 下载图片
	 * @param urlAddr
	 * @param getImageRelativePath将urlAddr 解析出相对路径，用于存储本地
	 */
	public String downImage(String urlAddr,String localRelativeAddr) {
		// String urlAddr="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1563005187&di=20f448eb885709b4a3e6ec3e859df20a&imgtype=jpg&er=1&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201806%2F03%2F20180603151807_xakqk.thumb.700_0.jpg";
		try {
			URL url = new URL(urlAddr);
			HttpURLConnection http = (HttpURLConnection) url.openConnection();
			InputStream is = http.getInputStream();
			String resourcePath= DownloadFile.class.getResource("/").getFile();
			File file = new File(java.net.URLDecoder.decode(resourcePath)+destPath+"//"+localRelativeAddr);
			File fileParent = file.getParentFile();  
			if(!fileParent.exists()){  
			    fileParent.mkdirs();  
			}  
			if(!file.exists()){
				file.createNewFile();
			}
			String fileName=file.getAbsolutePath();
			OutputStream os = new FileOutputStream(fileName);
			byte by[] = new byte[1024];
			int len = 0;
			while ((len = is.read(by, 0, by.length)) != -1) {
				os.write(by, 0, len);
			}
			os.close();
			is.close();
			return fileName;
		} catch (Exception e) {
			// TODO: handle exception
			LOG.error(e.getMessage(),e);
		}
		return null;
	}
}
