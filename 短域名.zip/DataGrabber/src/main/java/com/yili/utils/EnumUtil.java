package com.yili.utils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EnumUtil {

	public enum DataTypeEnum {

		CHARACTER("字符串", 1), INTEGER("整数", 2), BOOLEAN("布尔型", 3), DATE("日期", 4), DOUBLE("双精度", 5), DECIMAL("十进制", 6);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private DataTypeEnum(String name, int index) {
			this.name = name;
			this.index = index;
		}

		// 普通方法
		public static String getName(int index) {
			for (DataTypeEnum c : DataTypeEnum.values()) {
				if (c.getIndex() == index) {
					return c.name;
				}
			}
			return null;
		}

		// 普通方法
		public static Object getDefaultValue(Integer index) {
			Object dObject = "";
			switch (index) {
			case 1:
				dObject = "\"\"";
				break;
			case 2:
				dObject = 0;
				break;
			case 3:
				dObject = true;
				break;
			case 4:
				dObject = "\"\"";
				break;
			case 5:
				dObject = 0.0;
				break;
			case 6:
				dObject = 0;
				break;
			default:
				break;
			}
			return dObject;
		}

		// get set 方法
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public int getIndex() {
			return index;
		}

		public void setIndex(int index) {
			this.index = index;
		}
	}

	/**
	 * 客户关系
	 * 
	 * @author user
	 *
	 */
	public enum EnumManageType {
		Direct("直管", "01", 1), Assist("协管理", "02", 2);
		// 成员变量
		private String name;
		private String code;
		private int index;

		// 构造方法
		private EnumManageType(String name, String code, int index) {
			this.name = name;
			this.index = index;
			this.code = code;
		}

		public String getCode() {
			return this.code;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/**
	 * 
	 * @author user
	 *
	 */
	public enum EnumYesOrNo {
		Yes("是", 1), No("否", 0);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumYesOrNo(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	public enum EnumEconomicForm {
		c("C-经济下行", 1), d("D-经济复苏", 2);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumEconomicForm(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 审核状态
	/// </summary>
	public enum EnumAuditStatus {

		NoPass("不通过", -1), Submit("提交", 0), Pass("通过", 1), Audit("审核中", 2), NoSubmit("未提交", 3);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumAuditStatus(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 消息类型
	/// </summary>
	public enum EnumInfoType {
		System("系统消息", 1), Ordinary("普通消息", 2), logout("注销通知", 3);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumInfoType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 储蓄类型
	/// </summary>
	public enum EnumDepositType {
		Large("人民币大额存单", 1), Current("人民币（外汇）活期储蓄", 2), DepositTaking("人民币（外币）整存整取定期储蓄", 3), ZeroSaving("人民币零存整取定期储蓄",
				4), Education("人民币教育储蓄", 5), TakeInterest("人民币存本取息定期储蓄",
						6), WholeZero("人民币整存零取定期储蓄", 7), DoubleSave("人民币定活两便储蓄", 8), Notice("人民币（外汇）个人通知存款", 9);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumDepositType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 小额产品储存期限
	/// </summary>
	public enum EnumStoragePeriod {
		Month("一个月", 1), ThreeMonths("三个月", 2), HalfYear("半年", 3), Year("一年", 4), TwoYears("二年", 5), ThreeYears("三年",
				6), FiveYears("五年", 7), SixYears("六年", 8), No("不定期", 9);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumStoragePeriod(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 贵金属
	/// </summary>
	public enum EnumNobleMetal {
		Gold("广东农行人民币账户黄金", 1), Silver("广东农行人民币账户白银", 2), Platinum("广东农行人民币账户铂金", 3), Palladium("广东农行人民币账户钯金",
				4), USAGold("广东农行美元账户黄金",
						5), USASilver("广东农行美元账户白银", 6), USAPlatinum("广东农行美元账户铂金", 7), USAPalladium("广东农行美元账户钯金", 8);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumNobleMetal(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 手机系统类型
	/// </summary>
	public enum EnumSystemType {
		No("", 0),
		// 非货币
		Android("Android", 1), IOS("IOS", 2), PC("PC", 3), WeiXin("微信", 4);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumSystemType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// value_type` int(11) DEFAULT NULL COMMENT
	/// '收益公布形式：1-净值，21-百份收益,22-万份收益，23-百万份收益',
	/// 1-净值:1、2、6、7、8、9、10、11、12
	/// 21-百份收益：6、7、8、9、10、11、12、20、21
	/// 22-万份收益：6、7、8、9、10、11、12、20、22
	/// 23-百万份收益'：6、7、8、9、10、11、12、20、23
	/// </summary>
	public enum EnumIncomeType {
		// 非货币
		Current("日涨跌幅", 1), Week("近一周收益", 2),

		// 共有
		OneMonths("近一月收益", 6), ThreeMonths("近三月收益", 7), SixMonths("近六月收益", 8), NearlyOneYear("近一年收益",
				9), NearlyTwoYear("近两年收益", 10), NearlyThreeYear("近三年收益", 11), ThisYear("今年以来收益", 12),

		// 所有货币都有
		SevenDays("七日年化收益", 20),

		// 独有21
		Hundred("百份收益", 21),

		TenThousand("万份收益", 22), Million("百万份收益", 23);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumIncomeType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}

	}

	/// <summary>
	/// 数据类型
	/// </summary>
	public enum EnumValueType {
		Value("最新净值", 1), Hundred("百份收益", 21), TenThousand("万份收益", 22), Million("百万份收益", 23);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumValueType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 金融产品
	/// </summary>
	public enum EnumProduct {
		/// <summary>
		/// 大额存单
		/// </summary>
		Deposit("大额存单", 3), Fund("基金", 4), FinancialProducts("理财产品", 5), Insurance("保险", 6), NobleMetal("贵金属",
				7), Loan("贷款", 8), DepositSmall("其他储蓄产品", 9);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumProduct(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 前端标签
	/// </summary>
	public enum EnumProductTab {
		Recommend("推荐组合", 1, 1), Important("重点产品", 2, 2), Deposit("储蓄产品", 3, 3), Fund("基金", 4,
				5), FinancialProducts("理财产品", 5, 6), Insurance("保险", 6, 7), NobleMetal("贵金属", 7, 8), Loan("个贷产品", 8, 4);
		// 成员变量
		private String name;
		private int index;
		private int order;

		// 构造方法
		private EnumProductTab(String name, int index, int order) {
			this.name = name;
			this.index = index;
			this.order = order;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}

		public int getOrder() {
			return this.order;
		}
	}

	/// <summary>
	/// 岗位
	/// </summary>
	public enum EnumPost {
		DotWealthConsultant("网点财富顾问", 1), BranchWealthConsultant("支行财富顾问", 2), BranchWealthAdvisor("分行财富顾问",
				3), ProvincialWealthAdvisor("省行财富顾问", 4);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumPost(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}

		public static String getName(int index) {
			for (EnumPost c : EnumPost.values()) {
				if (c.getIndex() == index) {
					return c.name;
				}
			}
			return "";
		}
	}

	/// <summary>
	/// 学历枚举
	/// </summary>
	public enum EnumEducation {
		HighSchool("高中", 1), JuniorCollege("大专", 2), Undergraduate("本科", 3), Master("硕士研究生", 4), Doctor("博士研究生", 5);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumEducation(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}

		public static String getName(int index) {
			for (EnumEducation c : EnumEducation.values()) {
				if (c.getIndex() == index) {
					return c.name;
				}
			}
			return "";
		}
	}

	/// <summary>
	/// 移民状态
	/// </summary>
	public enum EnumCallStatus {
		HighSchool("正常受理", 0), JuniorCollege("停止办理", 1), Undergraduate("新推政策", 2), Master("重新开放", 3);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumCallStatus(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 移民类型
	/// </summary>
	public enum EnumImmigrantType {
		HighSchool("技术移民类", 1), JuniorCollege("家庭团聚类", 2), Undergraduate("商业移民类", 3), Other("其他移民类", 4);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumImmigrantType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 日志类型:1：登陆；2：客户；3、审核；4、资产配置；5、营销；6、资讯；7、浏览（查看报告书js）；11：后台消息；12、：后台客户；13、后台组合；14、后台产品
	/// 等
	/// </summary>
	public enum EnumLogType {
		Login("登陆", 1), Customer("客户", 2), Auditing("资产配置报告书审核", 3), Assets("资产配置报告书创建", 4), Marketing("市场营销", 5), News(
				"资讯", 6), Look("资产配置报告书浏览", 7), Share("资产配置报告书分享", 8), Email("资产配置报告书邮件", 9), MLogin("后台登陆",
						10), MInformation("后台消息", 11), MCustomer("后台客户", 12), MCombination("后台推荐", 13), MProduct("后台产品",
								14), Fund("基金分享", 21), Product("理财产品分享",
										22), Insurance("保险分享", 23), FixedInvestment("定投模拟分享", 24);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumLogType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 子类型:1、增；2：删；3、改；4、查； 等
	/// </summary>
	public enum EnumLogSubType {

		Add("新增", 1), Delete("删除", 2), Modify("修改", 3), Look("查询", 4);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumLogSubType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 浏览平台:1、微信；2、邮件；3、朋友圈；4、微博；5：QQ
	/// </summary>
	public enum EnumLogPlatform {
		Other("其他", 0), WeiXin("微信", 1), Email("邮件", 2), Friends("朋友圈", 3), Blog("微博", 4), QQ("QQ", 5);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumLogPlatform(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 报告书类型
	/// </summary>
	public enum EnumReportType {
		AssetConfig("资产配置", 1), Fund("基金", 2), FinancialProducts("理财产品", 3), Insurance("保险", 4);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumReportType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	// 客户信息
	/// <summary>
	/// 风险
	/// </summary>
	public enum EnumRiskType {
		Keep("保守型", 1), Careful("谨慎型", 2), Stable("稳健型", 3), Active("进取型", 4), Radical("激进型", 5);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumRiskType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}

		public static String getEnumName(int index) {
			for (EnumRiskType c : EnumRiskType.values()) {
				if (c.getIndex() == index) {
					return c.getName();
				}
			}
			return null;
		}
	}

	/// <summary>
	/// 客户属性
	/// </summary>
	public enum EnumCustomerType {
		// New("财富新贵", 1), Grow("财富成长", 2), Keep("财富守护", 3), Hierarchy("财富传承", 4);
		Financial("理财级", 1), Wealth("财富级", 2), Private("私行级", 3);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumCustomerType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}

		public static String getEnumName(int index) {
			for (EnumCustomerType c : EnumCustomerType.values()) {
				if (c.getIndex() == index) {
					return c.getName();
				}
			}
			return null;
		}
	}

	/// <summary>
	/// 投资期限
	/// </summary>
	public enum EnumPeriodType {
		One("1年以内", 1), Two("1 - 3年", 2), Three("3年以上", 3);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumPeriodType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}

		public static String getEnumName(int index) {
			for (EnumPeriodType c : EnumPeriodType.values()) {
				if (c.getIndex() == index) {
					return c.getName();
				}
			}
			return null;
		}
	}

	/// <summary>
	/// 投资资金
	/// </summary>
	public enum EnumMoneyType {
		Keep("10万", 1), Careful("100万", 2), Stable("500万", 3), Active("1000万", 4), Radical("5000万", 5);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumMoneyType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}

		public static String getEnumName(int index) {
			for (EnumMoneyType c : EnumMoneyType.values()) {
				if (c.getIndex() == index) {
					return c.getName();
				}
			}
			return null;
		}
	}

	// #region 客户属性
	/// <summary>
	/// 职业身份
	/// </summary>
	public enum EnumJobType {
		One("企业主", 1), Two("企业高管", 2), Three("企业职工", 3), Four("公务员", 4), Five("家庭主妇", 5), Six("退休人员", 6), Seven("自由职业",
				7);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumJobType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 家庭结构
	/// </summary>
	public enum EnumFamilyType {
		One("单身贵族", 1), Two("二人世界", 2), Three("三口之家", 3), Four("四口之家", 4), Five("三代同堂", 5), Six("单亲家庭", 6);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumFamilyType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 兴趣爱好 音乐，影视，阅读，金融行情，文娱表演，
	/// 健身，高尔夫球、足球、篮球、排球、
	/// 跑步、羽毛球、乒乓球、保龄球，
	/// 户外活动，网游，摄影，旅游，美食，书法，棋类，美容，其他
	/// </summary>
	public enum EnumInterestType {
		One("音乐", 1), Two("影视", 2), Four("阅读", 3), Five("金融行情", 4), Six("文娱表演", 5), One1("健身", 6), Two1("高尔夫球",
				7), Four1("足球", 8), Five1("篮球", 9), Six1("排球", 10),

		One2("跑步", 11), Two2("高尔夫球", 12), Four2("羽毛球", 13), Five2("乒乓球", 14), Six2("保龄球", 15),

		One3("户外活动", 16), Two3("网游", 17), Four3("摄影", 18), Five3("旅游", 19), Six3("美食", 20),

		One4("书法", 21), Two4("棋类", 22), Four4("美容", 23), Five4("其他", 24);

		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumInterestType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 产品偏好
	/// </summary>
	public enum EnumProductFavorType {
		One("存款", 1), Two("银行理财", 2), Three("公募基金", 3), Four("私募基金", 4), Five("保险", 5), Six("贵金属", 6);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumProductFavorType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 非金融
	/// </summary>
	public enum EnumNotFinancialType {
		One("法律咨询", 1), Two("税务咨询", 2), Three("财富传承", 3), Four("资产配置", 4), Five("融资服务", 5), Six("跨境金融", 6);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumNotFinancialType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	/// <summary>
	/// 理财产品操作类型
	/// </summary>
	public enum EnumOperateType {
		Replace("代替", 1), Hide("隐藏", 2), Add("新增", 3);
		// 成员变量
		private String name;
		private int index;

		// 构造方法
		private EnumOperateType(String name, int index) {
			this.name = name;
			this.index = index;
		}

		public String getName() {
			return this.name;
		}

		public int getIndex() {
			return this.index;
		}
	}

	private static Map<String, Map<Integer, String>> _EnumList = new HashMap<String, Map<Integer, String>>(); // 枚举缓存池

	/// <summary>
	/// 获取枚举说明
	/// </summary>
	/// <param name="enumType"></param>
	/// <param name="key"></param>
	/// <returns></returns>
	public static <T extends Enum<T>> String GetEnumDescription(Class<T> enumType, int key) {
		Map<Integer, String> dir = EnumToDictionary(enumType);
		if (dir != null && dir.containsKey(key)) {
			return dir.get(key);
		}
		return null;
	}

	private static Logger logger = LoggerFactory.getLogger(EnumUtil.class);

	/// <summary>
	/// 获取枚举属性名
	/// </summary>
	/// <param name="enumType"></param>
	/// <param name="key"></param>
	/// <returns></returns>
	public static <T extends Enum<T>> String GetEnumPropertyName(Class<T> enumType, int key) {
		try {
			EnumSet<T> sets = EnumSet.allOf(enumType);
			Method getIndex = enumType.getMethod("getIndex");
			for (Enum<T> enum1 : sets) {
				Object indexObj = getIndex.invoke(enum1);
				Integer index = Integer.valueOf(indexObj.toString());
				if (index.equals(key)) {
					return enum1.name();
				}
			}
			return "";
		} catch (Exception e) {
			// TODO: handle exception
			return "";
		}
	}

	public static <T extends Enum<T>> T GetEnum(Class<T> enumType, int key) {
		try {
			EnumSet<T> sets = EnumSet.allOf(enumType);
			Method getIndex = enumType.getMethod("getIndex");
			for (Enum<T> enum1 : sets) {
				Object indexObj = getIndex.invoke(enum1);
				Integer index = Integer.valueOf(indexObj.toString());
				if (index.equals(key)) {
					return Enum.valueOf(enumType, enum1.name());
				}
			}
			return null;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			// TODO: handle exception
			return null;
		}
	}

	/// <summary>
	/// 获取属性名和值字典
	/// </summary>
	/// <param name="enumType"></param>
	/// <returns></returns>
	public static <T extends Enum<T>> Map<String, Integer> EnumToPropertyDictionary(Class<T> enumType) {
		try {
			Map<String, Integer> list = new HashMap<String, Integer>();
			EnumSet<T> sets = EnumSet.allOf(enumType);
			Method getIndex = enumType.getMethod("getIndex");
			for (Enum<T> enum1 : sets) {
				Object index = getIndex.invoke(enum1);
				list.put(enum1.name(), Integer.valueOf(index.toString()));
			}
			return list;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			// TODO: handle exception
			return new HashMap<String, Integer>();
		}
	}

	/**
	 * 枚举 属性名字和index
	 * 
	 * @param enumType
	 * @return
	 */
	public static <T extends Enum<T>> Map<Integer, String> EnumPToDictionary(Class<T> enumType) {
		try {
			Map<Integer, String> list = new HashMap<Integer, String>();
			EnumSet<T> sets = EnumSet.allOf(enumType);
			Method getIndex = enumType.getMethod("getIndex");
			for (Enum<T> enum1 : sets) {
				Object index = getIndex.invoke(enum1);
				list.put(Integer.valueOf(index.toString()), enum1.name());
			}
			return list;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			// TODO: handle exception
			return new HashMap<Integer, String>();
		}
	}

	/// <summary>
	/// 获取枚举描述信息
	/// </summary>
	/// <param name="en"></param>
	/// <returns>如果没有则返回值</returns>
	public static String GetEnumDescription(Enum en) throws NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Method getName = en.getClass().getMethod("getName");
		Object name = getName.invoke(en);
		return name != null ? name.toString() : "";
	}

	/// <summary>
	/// 将枚举转换成Dictionary&lt;int, string&gt;
	/// Dictionary中，key为枚举项对应的int值；value为：若定义了EnumShowName属性，则取它，否则取name
	/// </summary>
	/// <param name="enumType">枚举类型</param>
	/// <returns></returns>

	public static <T extends Enum<T>> Map<Integer, String> EnumToDictionary(Class<T> enumType) {
		try {
			String keyName = enumType.getName();
			if (!_EnumList.containsKey(keyName)) {
				Map<Integer, String> list = new HashMap<Integer, String>();
				Map<Integer, String> listTemp = new HashMap<Integer, String>();
				Map<Integer, Integer> orders = new LinkedHashMap<Integer, Integer>();

				EnumSet<T> sets = EnumSet.allOf(enumType);
				Method getIndex = enumType.getMethod("getIndex");
				Method getName = enumType.getMethod("getName");
				Method getOrder = null;
				for (Method m : enumType.getMethods()) {
					if (m.getName().equals("getOrder")) {
						getOrder = m;
						break;
					}
				}
				for (Enum<T> enum1 : sets) {
					Object index = getIndex.invoke(enum1);
					Object name = getName.invoke(enum1);
					Integer key = Integer.valueOf(index.toString());
					if (getOrder != null) {
						Object order = getOrder.invoke(enum1);
						orders.put(Integer.valueOf(order.toString()), key);
					}

					listTemp.put(key, name.toString());

				}
				if (orders.size() > 0) {
					Set<Integer> orKeys = orders.keySet();
					for (Integer key : orKeys) {
						list.put(orders.get(key), listTemp.get(orders.get(key)));
					}
				} else {
					list = listTemp;
				}
				Object syncObj = new Object();
				if (!_EnumList.containsKey(keyName)) {
					synchronized (syncObj) {
						if (!_EnumList.containsKey(keyName)) {
							_EnumList.put(keyName, list);
						}
					}
				}

			}
			return _EnumList.get(keyName);
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			return null;
			// TODO: handle exception
		}
	}
}
