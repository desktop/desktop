package com.yili.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class FtpUtil {

	private static final Logger log = LoggerFactory.getLogger(FtpUtil.class);
	// ftp服务器ip地址

	private static String FTP_ADDRESS = "";

	@Value("${spring.ftp.address}")
	public void setAddress(String address) {
		FtpUtil.FTP_ADDRESS = address;
	}

	// 端口号
	private static int FTP_PORT = 21;

	@Value("${spring.ftp.port}")
	public void setPort(int port) {
		FtpUtil.FTP_PORT = port;
	}

	// 用户名
	private static String FTP_USERNAME = "";

	@Value("${spring.ftp.userName}")
	public void setUserName(String userName) {
		FtpUtil.FTP_USERNAME = userName;
	}

	// 密码
	private static String FTP_PASSWORD = "";

	@Value("${spring.ftp.password}")
	public void setPassword(String password) {
		FtpUtil.FTP_PASSWORD = password;
	}

	/**
	 * 检查ftp服务器可用（0：不可用，1：可用，2：连接超时）
	 * 
	 */
	public static int checkAttachFtpServer(String ftpHost) {
		FTPClient ftpClient = new FTPClient();
		try {
			ftpClient = new FTPClient();
			ftpClient.setConnectTimeout(5000);// 最长5秒
			String host = "";
			Integer portNo = FTP_PORT;
			List<String> hostArr = getHostPortNo(ftpHost);
			if (hostArr != null && hostArr.size() > 1) {
				host = hostArr.get(0);
				portNo = Integer.parseInt(hostArr.get(1));
			}
			ftpClient.connect(host, portNo);// 连接FTP服务器
			if (!FTPReply.isPositiveCompletion(ftpClient.getReplyCode())) {
				log.error("未连接到FTP，用户名或密码错误。");

			} else {
				log.info("FTP连接成功。");
				return 1;
			}
		} catch (SocketTimeoutException e) {
			// e.printStackTrace();
			log.error("FTP的IP地址可能错误，请正确配置。");
			return 2;
		} catch (SocketException e) {
			// e.printStackTrace();
			log.error("FTP的IP地址可能错误，请正确配置。");

		} catch (IOException e) {
			// e.printStackTrace();
			log.error("FTP的端口错误,请正确配置。");
		} finally {
			try {
				ftpClient.disconnect();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
			}
		}
		return 0;
	}

	/**
	 * 获取FTPClient对象
	 * 
	 * @param ftpHost
	 *            FTP主机服务器
	 * @param ftpPassword
	 *            FTP 登录密码
	 * @param ftpUserName
	 *            FTP登录用户名
	 * @param ftpPort
	 *            FTP端口 默认为21
	 * @return
	 */
	public static FTPClient getFTPClient(String ftpHost, String ftpUserName, String ftpPassword) {
		FTPClient ftpClient = null;
		try {

			ftpClient = new FTPClient();
			String host = "";
			Integer portNo = FTP_PORT;
			List<String> hostArr = getHostPortNo(ftpHost);
			if (hostArr != null && hostArr.size() > 1) {
				host = hostArr.get(0);
				portNo = Integer.parseInt(hostArr.get(1));
			}
			ftpClient.connect(host, portNo);// 连接FTP服务器
			ftpClient.login(ftpUserName, ftpPassword);// 登陆FTP服务器
			ftpClient.setSoTimeout(3 * 60 * 1000);// 最长5秒
			// 设置被动模式传输
			ftpClient.enterLocalPassiveMode();
			if (!FTPReply.isPositiveCompletion(ftpClient.getReplyCode())) {
				log.error("未连接到FTP，用户名或密码错误。");
				ftpClient.disconnect();
			} else {
				log.info("FTP连接成功。");
			}
		} catch (SocketException e) {
			// e.printStackTrace();
			log.error("FTP的IP地址可能错误，请正确配置。");
		} catch (IOException e) {
			try {
				Thread.sleep(30 * 1000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			ftpClient = reFTPClient(ftpHost, ftpUserName, ftpPassword);
		}
		return ftpClient;
	}

	/**
	 * 获取FTPClient对象
	 * 
	 * @param ftpHost
	 *            FTP主机服务器
	 * @param ftpPassword
	 *            FTP 登录密码
	 * @param ftpUserName
	 *            FTP登录用户名
	 * @param ftpPort
	 *            FTP端口 默认为21
	 * @return
	 */
	public static FTPClient reFTPClient(String ftpHost, String ftpUserName, String ftpPassword) {
		FTPClient ftpClient = null;
		try {

			ftpClient = new FTPClient();
			String host = "";
			Integer portNo = FTP_PORT;
			List<String> hostArr = getHostPortNo(ftpHost);
			if (hostArr != null && hostArr.size() > 1) {
				host = hostArr.get(0);
				portNo = Integer.parseInt(hostArr.get(1));
			}
			ftpClient.connect(host, portNo);// 连接FTP服务器
			ftpClient.login(ftpUserName, ftpPassword);// 登陆FTP服务器
			ftpClient.setSoTimeout(3 * 60 * 1000);// 最长5秒
			// 设置被动模式传输
			ftpClient.enterLocalPassiveMode();
			if (!FTPReply.isPositiveCompletion(ftpClient.getReplyCode())) {
				log.error("未连接到FTP，用户名或密码错误。");
				ftpClient.disconnect();
			} else {
				log.info("FTP连接成功。");
			}
		} catch (SocketException e) {
			// e.printStackTrace();
			log.error("FTP的IP地址可能错误，请正确配置。");
		} catch (IOException e) {
			// e.printStackTrace();
			log.error("FTP的端口错误,请正确配置。");
			ftpClient = getFTPClient(ftpHost, ftpUserName, ftpPassword);
		}
		return ftpClient;
	}

	/**
	 * 获取端口号
	 * 
	 */
	private static List<String> getHostPortNo(String url) {
		List<String> result = new ArrayList<String>();
		String portNo = FTP_PORT + "";
		if (url != null && url.indexOf(":") > 0) {
			String[] hosts = url.split(":");
			url = hosts[1].replace("/", "").replace("\\", "");
			portNo = hosts[2].replace("/", "").replace("\\", "");
		}
		result.add(url);
		result.add(portNo);
		return result;
	}

	/**
	 * Description: 向FTP服务器上传文件
	 * 
	 * @param localFileName
	 *            FTP服务器文件存放路径。例如:D:/发布/20180424130806641.jpg
	 * @param ftpFileName
	 *            上传到FTP服务器上的路径,不包括ftp地址，例如 :yili/2019-01-01/2222.jpg
	 * @return 成功返回true，否则返回false
	 */
	public static boolean uploadFile(String localFileName, String ftpFileName) {

		boolean flag = false;
		try {
			String[] arr = ftpFileName.split("/");
			int length = arr.length;
			String filename = arr[length - 1];
			FileInputStream input = null;
			File srcFile = new File(localFileName);
			input = new FileInputStream(srcFile);

			flag = uploadFile(ftpFileName.substring(0, ftpFileName.length() - (filename.length()) - 1), filename,
					input);
		} catch (Exception e) {

			return false;
		}
		return flag;

	}

	/**
	 * Description: 向FTP服务器上传文件
	 * 
	 * @param filePath
	 *            FTP服务器文件存放路径。例如:"yili/2019-01-01"
	 * @param filename
	 *            上传到FTP服务器上的文件名:2222.jpg
	 * @param input
	 *            输入流
	 * @return 成功返回true，否则返回false
	 */
	public static boolean uploadFile(String filePath, String filename, InputStream input) {
		boolean result = false;
		FTPClient ftp = null;
		try {
			try {
				Thread.sleep(10 * 1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ftp = getFTPClient(FTP_ADDRESS, FTP_USERNAME, FTP_PASSWORD);
			if (ftp != null && ftp.isConnected()) {
				// 切换到上传目录
				if (!createDir(ftp, filePath)) {
					log.error("切入FTP目录失败");
					return false;
				}
				// 设置上传文件的类型为二进制类型
				ftp.setFileType(FTP.BINARY_FILE_TYPE);

				// 上传文件
				if (!ftp.storeFile(filename, input)) {
					return result;
				}
				result = true;
			}

		} catch (IOException e) {
			log.error("上传至FTP异常:" + e.getMessage(), e);
		} finally {
			try {
				if (input != null) {
					input.close();
				}
			} catch (IOException ioe) {
			}

			if (ftp != null) {
				try {
					if (ftp.isConnected()) {
						ftp.logout();
					}
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					try {

						ftp.disconnect();
						System.out.println("关闭ftp连接成功");
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}

		}
		return result;
	}

	/**
	 * 创建目录(有则切换目录，没有则创建目录)
	 * 
	 * @param dir
	 * @return
	 */
	public static synchronized boolean createDir(FTPClient ftp, String dir) {

		String d;
		try {
			// 目录编码，解决中文路径问题
			d = new String(dir.toString().getBytes("GBK"), "iso-8859-1");
			// 尝试切入目录
			if (ftp.changeWorkingDirectory(d))
				return true;
			String[] arr = dir.split("/");
			StringBuffer sbfDir = new StringBuffer();
			// 循环生成子目录
			for (String s : arr) {
				if (null == s || "".equals(s))
					continue;
				sbfDir.append("/");
				sbfDir.append(s);
				// 目录编码，解决中文路径问题
				d = new String(sbfDir.toString().getBytes("GBK"), "iso-8859-1");
				// 尝试切入目录
				if (ftp.changeWorkingDirectory(d))
					continue;
				if (!ftp.makeDirectory(d)) {
					return false;
				}
			}
			// 将目录切换至指定路径
			return ftp.changeWorkingDirectory(d);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	/*
	 * 从FTP服务器下载文件
	 * 
	 * @param ftpHost FTP IP地址
	 * 
	 * @param ftpUserName FTP 用户名
	 * 
	 * @param ftpPassword FTP用户名密码
	 * 
	 * @param ftpPath FTP服务器中文件所在路径 格式： ftptest/aa
	 * 
	 * @param localPath 下载到本地的位置 格式：H:/download
	 * 
	 * @param fileName 文件名称
	 */
	public static void downloadFtpFile(String ftpHost, String ftpUserName, String ftpPassword, String ftpPath,
			String localPath, String fileName) {

		FTPClient ftpClient = null;

		try {
			ftpClient = getFTPClient(ftpHost, ftpUserName, ftpPassword);
			ftpClient.setControlEncoding("UTF-8"); // 中文支持
			ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
			ftpClient.enterLocalPassiveMode();
			ftpClient.changeWorkingDirectory(ftpPath);

			File localFile = new File(localPath + File.separatorChar + fileName);
			OutputStream os = new FileOutputStream(localFile);
			ftpClient.retrieveFile(fileName, os);
			os.close();
			ftpClient.logout();

		} catch (FileNotFoundException e) {
			log.error("没有找到" + ftpPath + "文件");
			// e.printStackTrace();
		} catch (SocketException e) {
			log.error("连接FTP失败.");
			// e.printStackTrace();
		} catch (IOException e) {
			// e.printStackTrace();
			log.error("文件读取错误。");
			// e.printStackTrace();
		}

	}
}
