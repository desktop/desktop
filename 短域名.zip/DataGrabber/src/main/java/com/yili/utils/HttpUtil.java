package com.yili.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.yili.bean.EnumUserAgent;
import com.yili.bean.ResponeCode;
import com.yili.bean.ResultData;
import com.yili.kafka.CustomPartitioner;

/**
 * 进行http 请求
 * 
 * @author user
 *
 */
public class HttpUtil {
	private static Logger LOG = LoggerFactory.getLogger(CustomPartitioner.class);

	public static ResultData<JSONObject> sendPost(String url, Map<String, Object> param) {
		ResultData<JSONObject> resultD = new ResultData<JSONObject>();
		resultD.setCode(ResponeCode.Fail.getIndex());
		try {
			RestTemplate restTemplate = new RestTemplate();
			URI uri = new URI(url);
			HttpHeaders headers = new HttpHeaders();
			// headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			headers.add("content-type", "application/x-www-form-urlencoded; charset=UTF-8");
			headers.add("user-agent", EnumUserAgent.WeixinAgent.getName());
			MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
			for (String key : param.keySet()) {
				map.add(key, param.get(key) == null ? "" : param.get(key).toString());
			}
			HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(map, headers);
			JSONObject resultObj = restTemplate.postForObject(uri, httpEntity, JSONObject.class);
			resultD.setCode(ResponeCode.Success.getIndex());
			resultD.setData(resultObj);
			return resultD;
		} catch (URISyntaxException e) {
			// TODO: handle exception
			LOG.error("url转URI异常", e);
			resultD.setMessage("url转URI异常");
		} catch (Exception e) {
			// TODO: handle exception
			LOG.error(e.getMessage(), e);
			resultD.setMessage(ResponeCode.Fail.getName());
		}
		return resultD;
	}

	/**
	 * 进行get请求
	 * 
	 * @param url
	 * @param ignoreSSL 是否跳过ssl证书，默认不忽略
	 * @return
	 */
	public static ResultData<String> sendGet(String url, Boolean ignoreSSL) {
		ResultData<String> resultD = new ResultData<String>();
		resultD.setCode(ResponeCode.Fail.getIndex());
		if (ignoreSSL == null) {
			ignoreSSL = false;
		}
		try {
			RestTemplate restTemplate;
			if (ignoreSSL) {
				// 忽略ssl验证，否则微信无法访问
				HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
				factory.setConnectionRequestTimeout(300000);
				factory.setConnectTimeout(300000);
				factory.setReadTimeout(300000);
				// https
				CloseableHttpClient httpClient = getHttpsClient();
				factory.setHttpClient(httpClient);
				restTemplate = new RestTemplate(factory);
			} else {
				restTemplate = new RestTemplate();
			}
			restTemplate.getMessageConverters().set(1, new StringHttpMessageConverter(StandardCharsets.UTF_8));
			HttpHeaders headers = new HttpHeaders();
			headers.add("Accept", "text/html; charset=UTF-8");
			headers.add("Content-Type", "text/html; charset=UTF-8");
			headers.add("user-agent", EnumUserAgent.BrowserUserAgent.getName());
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
			URI uri = new URI(url);
			ResponseEntity<String> result = restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);
			resultD.setCode(ResponeCode.Success.getIndex());
			resultD.setData(result.getBody());
			return resultD;
		} catch (URISyntaxException e) {
			// TODO: handle exception
			LOG.error("url转URI异常", e);
			resultD.setMessage("url转URI异常");
		} catch (Exception e) {
			// TODO: handle exception
			LOG.error(e.getMessage(), e);
			resultD.setMessage(ResponeCode.Fail.getName());
		}
		return resultD;
	}

	private static CloseableHttpClient getHttpsClient() {
		CloseableHttpClient httpClient;
		SSLContext sslContext = null;
		try {
			sslContext = SSLContexts.custom().loadTrustMaterial(null, new TrustStrategy() {
				@Override
				public boolean isTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
					return true;
				}
			}).build();
		} catch (NoSuchAlgorithmException e) {
			e.getStackTrace();
		} catch (KeyManagementException e) {
			e.getStackTrace();
		} catch (KeyStoreException e) {
			e.getStackTrace();
		}
		httpClient = HttpClients.custom().setSSLContext(sslContext).setSSLHostnameVerifier(new NoopHostnameVerifier())
				.build();
		return httpClient;
	}

}
