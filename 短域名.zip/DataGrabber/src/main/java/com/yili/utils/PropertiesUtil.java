package com.yili.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesUtil {

	public static String GetConfigValue(String key) {
		String result = "";
		InputStream in = null;
		try {
			Properties properties = new Properties();
			// 使用ClassLoader加载properties配置文件生成对应的输入流
			in = PropertiesUtil.class.getClassLoader().getResourceAsStream("config.properties");
			// 使用properties对象加载输入流
			properties.load(in);
			// 获取key对应的value值
			result = properties.getProperty(key);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return result;
	}
}
