﻿/*后台接口访问地址域名*/
//var interfaceUrl = "http://114.113.151.70:8090/api";
//var interfaceUrl = "http://192.168.1.96:8100/api";
//var interfaceUrl = "/manage";
var interfaceUrl = "http://localhost:8006/manage";
//var interfaceUrl = "/manage";
//setCookie("manange_token", "aVUIqn7MvfwpJZA4qZIJyGa+f8LDnT84");
//setCookie("manange_name", "管理员");
//setCookie("manange_id",1);

var pageSize = 10;
$(function () {
	jQuery.support.cors = true;
	/**
	 * ajax封装
	 * url 发送请求的地址
	 * data 发送到服务器的数据，数组存储，如：{"date": new Date().getTime(), "state": 1}
	 * async 默认值: true。默认设置下，所有请求均为异步请求。如果需要发送同步请求，请将此选项设置为 false。
	 *    注意，同步请求将锁住浏览器，用户其它操作必须等待请求完成才可以执行。
	 * type 请求方式("POST" 或 "GET")， 默认为 "GET"
	 * dataType 预期服务器返回的数据类型，常用的如：xml、html、json、text
	 * successfn 成功回调函数
	 * errorfn 失败回调函数
	 */
	/**
	 * ajax封装
	 * url 发送请求的地址
	 * data 发送到服务器的数据，数组存储，如：{"date": new Date().getTime(), "state": 1}
	 * successfn 成功回调函数
	 */
	jQuery.postJson = function (url, data, successfn, ajaxParam, methodType, domain) {
	    if (ajaxParam == undefined) {
	        ajaxParam = {
	            contentType: "application/json;charset=utf-8",
	            dataType: "json",
	            async: true,
	            isLoading:true
	        }
	    }
	    else {
	        if (ajaxParam.contentType == undefined) {
	            ajaxParam.contentType = "application/json;charset=utf-8";
	        }
	        if (ajaxParam.dataType == undefined) {
	            ajaxParam.dataType = "json";
	        }
	        if (ajaxParam.async == undefined) {
	            ajaxParam.async = true;
	        }
	        if (ajaxParam.isLoading == undefined || ajaxParam.isLoading) {
	            ajaxParam.isLoading = true;
	           
	        }
	    }
	    if (domain == undefined || domain == "" || domain == "") {
	        domain = interfaceUrl;
	    }
	    if (ajaxParam.isLoading)
	    {
             showLoading(true);
	    }
	    $.ajax({
	        type: methodType == undefined ? "post" : "get",
	        data: methodType == undefined ? data: "",
	        contentType: ajaxParam.contentType,
	        headers: { 'Authorization': getCookie("manange_token"), "x-token": "1" },
	        url: domain + "/" + url,
	        dataType: ajaxParam.dataType,
	        async: ajaxParam.async,
	        /**
            * 必须false才会避开jQuery对 formdata 的默认处理
            * XMLHttpRequest会对 formdata 进行正确的处理
            */
	        processData: ajaxParam.processData == undefined ? false : ajaxParam.processData,
	        success: function (d) {
	            if (ajaxParam.isLoading) {
	                showLoading(false);
	            }
	            if (d.code == -1) {
	                layui.use(['laypage', 'layer'], function () {
	                    var layer = layui.layer;
	                    layer.alert(d.message, function () {
	                        window.parent.location.href = "login.html";
	                        return;
	                    });
	                });
	            } else {
	                successfn(d);
	            }
	        },
	        error: function (XMLHttpRequest, textStatus, errorMsg) {
	            if (ajaxParam.isLoading) {
	                showLoading(false);
	            }
	            layer.alert("可能由于网络原因操作失败，请刷新后再重试")
	            //layui.use(['laypage', 'layer'], function () {
	            //    var layer = layui.layer;
	            //    layer.alert("可能由于网络原因操作失败，请刷新后再重试");
	            //});
	          
	            if (ajaxParam.error != undefined) {
	                ajaxParam.error(errorMsg);
	            }
	            //$.showPopup("可能由于网络原因操作失败，请刷新后再重试")
	        }
	    });
	};
	jQuery.getFile= function(url,success) {
	    var xhr = new XMLHttpRequest();    
	    xhr.open("get", interfaceUrl + "/" + url, true);
	    xhr.responseType = "blob";
	    xhr.onload = function() {
	        if (this.status == 200) {
	            var blob = this.response;
	            if (success!=null) {
	                success(blob);
	            }
	        } 
	    }
	    xhr.onerror = function (XMLHttpRequest, textStatus, errorMsg) {
	        layer.alert("可能由于网络原因操作失败，请刷新后再重试");
	        //$.showPopup("可能由于网络原因操作失败，请刷新后再重试");
	    }
	    xhr.send();
	}
	//日志
	jQuery.log = function (type, subType, content, platform, url, userId, userName, postUrl) {
        
	    var rUrl = InterfaceUrl + "/Common/Log?ran=" + Math.random();
	    if (!isNullOrEmpty(postUrl)) {
	        rUrl = postUrl;
	    }
	    var data = { "id": decodeURIComponent(userId), "type": type, "subType": subType, "systemType": 0, "platform": platform, "content": content, "url": url }
		$.postJson(rUrl, data, function () {

		});
	};
	/** post 文件数据
	* ajax封装
	* url 发送请求的地址
	* data 发送到服务器的数据，数组存储，如：{"date": new Date().getTime(), "state": 1}
	* successfn 成功回调函数
	*/
	jQuery.ajaxFile = function (obj) {
		$.ajax({
			type: "post",
			data: obj.data,
			url: InterfaceUrl + "/" + obj.url,
			cache: false,
			async: obj.async == null ? true : false,
			processData: false,
			contentType: false,
			dataType: "json",
			success: function (d) {
				obj.success(d);
			},
			error: function (XMLHttpRequest, textStatus, errorMsg) {
			    layer.alert(errorMsg);
				//$.popupMsg(errorMsg);
			}
		});
	};
	
	//jQuery.dragPage = function (id, fn) {
	//    var lastTouchY = 0;
	//    $(id).on('touchstart', function (e) {
	//        var touch = e.originalEvent.targetTouches[0];
	//        lastTouchY = touch.pageY;
	//    });
	//    $(id).on('touchend', function (e) {
	//        var touch = e.originalEvent.changedTouches[0];
	//        if (touch.pageX - lastTouchY < 0) {//向上滑动，加载新分页
	//            var scrollPos = $(window).scrollTop(), parentHeight = $(window).height(); //滚动条距离顶部的位置、容器高度
	//            var bodyHeight = $(id).height();
	//            var canLoad = parentHeight + scrollPos > bodyHeight;
	//            if (canLoad == false && parentHeight + scrollPos == bodyHeight)
	//                canLoad = Math.abs(touch.pageX - lastTouchY) > 2;
	//            if (canLoad) {
	//                fn();
	//            }
	//        }
	//    });
	//}
});

; (function ($) {
	$.showPopup = function (msg) {

		var setting = {
			id: 'auto',
			type: 'alert',//alert,confirm
			time: 2,
			msg: '正在加载中，请稍后'
		}
		var param = {
			msg: msg
		}
		//合并参数
		option = $.extend(setting, param);
		if (option.id == 'auto') {
			option.id = 'popup' + parseInt(Math.random() * 999999999 + 1);
			while ($("#" + option.id).length > 0) {
				option.id = 'popup' + parseInt(Math.random() * 999999999 + 1);
			}

		}
		var htmlDiv = '<div class="show_popup" id="' + option.id + '">'
			+ '<div class="popup_content">'
				+ '<div class="popup_mask_p" id="' + option.id + 'div">'
				+ '<p>' + option.msg + '</p>'
				+ '</div>'
				+ '</div>'
			+ ' </div>';
		$("body").append(htmlDiv);
		var popupId = option.id;
		var removeTime = option.time * 1000;
		//alert确定
		if (removeTime > 0) {
			setTimeout(
				function () {
					$("#" + popupId).remove();
				}, removeTime);
		}
		//显示当前的窗口
		return $("#" + option.id).show();
	}
}(jQuery))

; (function ($) {
	$.popupMsg = function (msg) {

		var setting = {
			id: 'auto',
			type: 'alert',//alert,confirm
			msg: '正在加载中，请稍后'
		}
		var param = {
			msg: msg
		}
		//合并参数
		option = $.extend(setting, param);
		if (option.id == 'auto') {
			option.id = 'popup' + parseInt(Math.random() * 999999999 + 1);
			while ($("#" + option.id).length > 0) {
				option.id = 'popup' + parseInt(Math.random() * 999999999 + 1);
			}

		}
		var htmlDiv = '<div class="show_popup" id="' + option.id + '">'
			+ '<div class="popup_content">'
				+ '<div class="popup_mask_p" id="' + option.id + 'div">'
				+ '<p>' + option.msg + '</p>'
				+ '</div>'
				+ ' <div class="popup_mask_btn">'
						+ ' <input type="button" id="btnPopupOk' + option.id + '" value="确定" class="define" />'
				+ ' </div>'
				+ '</div>'
			+ ' </div>';
		$("body").append(htmlDiv);
		var popupId = option.id;
		//alert确定
		$("#btnPopupOk" + popupId).click(function () {
			$("#" + popupId).remove();
		});
		//显示当前的窗口
		return $("#" + option.id).show();
	}
}(jQuery))
; (function ($) {
	$.showPopupMsg = function (msg, optionfn) {

		var setting = {
			id: 'auto',
			type: 'alert',//alert,confirm
			msg: '正在加载中，请稍后'
		}
		var param = {
			msg: msg,
			fn: optionfn
		}
		//合并参数
		option = $.extend(setting, param);
		if (option.id == 'auto') {
			option.id = 'popup' + parseInt(Math.random() * 999999999 + 1);
			while ($("#" + option.id).length > 0) {
				option.id = 'popup' + parseInt(Math.random() * 999999999 + 1);
			}

		}
		var htmlDiv = '<div class="show_popup" id="' + option.id + '">'
			+ '<div class="popup_content">'
				+ '<div class="popup_mask_p" id="' + option.id + 'div">'
				+ '<p>' + option.msg + '</p>'
				+ '</div>'
				+ ' <div class="popup_mask_btn">'
						+ ' <input type="button" id="btnPopupSure' + option.id + '" value="确定" class="define" />'
				+ ' </div>'
				+ '</div>'
			+ ' </div>';
		$("body").append(htmlDiv);
		var popupId = option.id;
		//alert确定
		$("#btnPopupSure" + popupId).click(function () {
			$("#" + popupId).remove();
			if (optionfn != null) {
				optionfn();
			}
		});
		//显示当前的窗口
		return $("#" + option.id).show();
	}
}(jQuery))
; (function ($) {
	$.showConfirm = function (msg, textArr, optionfn) {
		var setting = {
			id: 'auto',
			msg: '正在加载中，请稍后',
			textArr: ['确定', '取消']
		}
		var param = {
			msg: msg,
			fn: optionfn,
			textArr: textArr
		}
		//合并参数
		option = $.extend(setting, param);

		if (option.id == 'auto') {
			option.id = 'popup' + parseInt(Math.random() * 999999999 + 1);
			while ($("#" + option.id).length > 0) {
				option.id = 'popup' + parseInt(Math.random() * 999999999 + 1);
			}

		}
		if (option.textArr == null || option.textArr.length != 2) {
			option.textArr = setting.textArr;
		}

		var htmlDiv = '<div class="show_popup" id="' + option.id + '">'
			+ '<div class="popup_content">'
				+ '<div class="popup_mask_p" id="' + option.id + 'div">'
				+ '<p>' + option.msg + '</p>'
				+ '</div>'
				   + ' <div class="popup_mask_btn2">'
							 + ' <input type="button" id="btnPopupCancle' + option.id + '" value="' + textArr[1] + '" class="define" />'
							 + ' <input type="button" id="btnPopupOption' + option.id + '"  value="' + textArr[0] + '" class="define" />'
						+ ' </div>'
				 + '</div>'
			 + ' </div>';
		$("body").append(htmlDiv);
		var popupId = option.id;
		var flag = true;
		//confirm 确定
		$("#btnPopupOption" + popupId).click(function () {
			flag = false
			if (optionfn != null) {
				optionfn(true);
			}
			$("#" + popupId).remove();
		});
		//confirm 取消
		$("#btnPopupCancle" + popupId).click(function () {
			flag = false
			if (optionfn != null) {
				optionfn(false);
			}
			$("#" + popupId).remove();
		});
		//显示当前的窗口
		$("#" + option.id).show();
		//if (flag) {
		//    setTimeout();
		//}
	}
}(jQuery))



var isBusy = false;
function createLoadingDiv() {
	var div = document.createElement("div");
	div.setAttribute("id", "divLoading");
    /*div.setAttribute("style", "position:absolute; left:0; top:0%; width:100%; line-height:10%; height:100%;z-index: 500;");*/
	div.innerHTML = '<div style="position: fixed; left: 50%; top:50%; width: 100%; line-height: 10%; height:100%; z-index: 1500;  display: block;">'
				  + '    <img alt="" src="/manage/images/loading_3.gif" class="loading" />'
				  + '</div>';
	document.body.appendChild(div);
}

function showLoading(isVisible) {
	if (isVisible) {
		isBusy = true;
	}

	if (!document.getElementById("divLoading")) {
		createLoadingDiv();
	}
	if (isVisible) {
		document.getElementById("divLoading").style.display = "block";
	} else {
		document.getElementById("divLoading").style.display = "none";
	}

	if (!isVisible) {
		isBusy = false;
	}
}
function encryptLong(str) {
    var encrypt = new JSEncrypt();
    encrypt.setPublicKey(publicKey);
    var encrys = [];
    if (str.length > 124) {
        var count = Math.ceil(str.length / 124);
        for (var i = 0; i < count; i++) {
            encrys.push(encrypt.encrypt(str.slice(124 * i, 124 * (i + 1))));
        }
    }
    else {
        encrys.push(encrypt.encrypt(str));
    }
    return encrys.join(" ");
}
//是否为空、undefined、空字符串、空格等 为空为true 否 false
function isNullOrEmpty(val) {
	var flag = false;
	if (val == null || val == 'undefined') {
		flag = true;
	}
	else {
		if (val.replace(/(^s*)|(s*$)/g, "").length == 0) {
			flag = true;
		}
	}
	return flag;
}
function NullOrEmpty(val) {
    if (val == null || val == 'undefined') {
        return "";
    }
    return val;
}
function isChinese(val) {
    var han = /^[\u4e00-\u9fa5]+$/;
    if (!han.test(val)) {
        return false;
    };
    return true;
}


//获取url中的参数
function getQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var r = window.location.search.substr(1).match(reg);
	if (r != null) return decodeURI(r[2]); return null;
}

String.prototype.gblen = function () {
    var len = 0;
    for (var i = 0; i < this.length; i++) {
        if (this.charCodeAt(i) > 127 || this.charCodeAt(i) == 94) {
            len += 2;
        } else {
            len++;
        }
    }
    return len;
}
String.prototype.trim = function () {
	return this.replace(/(^\s*)|(\s*$)/g, "");
};
String.prototype.ltrim = function () {
	return this.replace(/(^\s*)/g, "");
};
String.prototype.rtrim = function () {
	return this.replace(/(\s*$)/g, "");
};
String.prototype.replaceAll = function (find, newStr) {
	return this.replace(new RegExp(find, "gm"), newStr);
};
String.prototype.format = function (args) {
	var result = this.toString();
	var _dic = typeof args === "object" ? args : arguments;
	return result.replace(/\{([^{}]+)\}/g, function (str, key) {
		// return key in _dic ? _dic[key] : str;
		return _dic.hasOwnProperty(key) ? _dic[key] : str;
	});
};
Number.prototype.add = function (arg) {
	var r1, r2, m;
	try { r1 = this.toString().split(".")[1].length } catch (e) { r1 = 0 }
	try { r2 = arg.toString().split(".")[1].length } catch (e) { r2 = 0 }
	m = Math.pow(10, Math.max(r1, r2))
	return (this * m + arg * m) / m
}
Array.prototype.remove = function (val) {
	var index = this.indexOf(val);
	if (index > -1) {
		this.splice(index, 1);
	}
};


 
// JavaScript Document 
//--------------------------------------------------- 
// 判断闰年 
//--------------------------------------------------- 
Date.prototype.isLeapYear = function () {
	return (0 == this.getYear() % 4 && ((this.getYear() % 100 != 0) || (this.getYear() % 400 == 0)));
};
//--------------------------------------------------- 
// 日期格式化 
// 格式 YYYY/yyyy/YY/yy 表示年份 
// MM/M 月份 
// W/w 星期 
// dd/DD/d/D 日期 
// hh/HH/h/H 时间 
// mm/m 分钟 
// ss/SS/s/S 秒 
//--------------------------------------------------- 
// 对Date的扩展，将 Date 转化为指定格式的String 
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，香港服务器， 
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字) 
// 例子： 
// (new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423 
// (new Date()).Format("yyyy-M-d h:m:s.S") ==> 2006-7-2 8:9:4.18 
Date.prototype.Format = function (fmt) { //author: meizz 
	var o = {
		"M+": this.getMonth() + 1, //月份 
		"d+": this.getDate(), //日 
		"h+": this.getHours(), //小时 
		"H+": this.getHours(), //小时 
		"m+": this.getMinutes(), //分 
		"s+": this.getSeconds(), //秒 
		"q+": Math.floor((this.getMonth() + 3) / 3), //季度 
		"S": this.getMilliseconds() //毫秒 
	};
	if (/(y+)/.test(fmt))
		fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
	for (var k in o)
		if (new RegExp("(" + k + ")").test(fmt))
			fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
	return fmt;
};
/** 
* 对Date的扩展，将 Date 转化为指定格式的String 
* 月(M)、日(d)、12小时(h)、24小时(H)、分(m)、秒(s)、周(E)、季度(q) 可以用 1-2 个占位符 
* 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字) 
* eg: 
* (new Date()).pattern("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423 
* (new Date()).pattern("yyyy-MM-dd E HH:mm:ss") ==> 2009-03-10 二 20:09:04 
* (new Date()).pattern("yyyy-MM-dd EE hh:mm:ss") ==> 2009-03-10 周二 08:09:04 
* (new Date()).pattern("yyyy-MM-dd EEE hh:mm:ss") ==> 2009-03-10 星期二 08:09:04 
* (new Date()).pattern("yyyy-M-d h:m:s.S") ==> 2006-7-2 8:9:4.18 
*/
Date.prototype.pattern = function (fmt) {
	var o = {
		"M+": this.getMonth() + 1, //月份 
		"d+": this.getDate(), //日 
		"h+": this.getHours() % 12 == 0 ? 12 : this.getHours() % 12, //小时 
		"H+": this.getHours(), //小时 
		"m+": this.getMinutes(), //分 
		"s+": this.getSeconds(), //秒 
		"q+": Math.floor((this.getMonth() + 3) / 3), //季度 
		"S": this.getMilliseconds() //毫秒 
	};
	var week = {
		"0": "/u65e5",
		"1": "/u4e00",
		"2": "/u4e8c",
		"3": "/u4e09",
		"4": "/u56db",
		"5": "/u4e94",
		"6": "/u516d"
	};
	if (/(y+)/.test(fmt)) {
		fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
	}
	if (/(E+)/.test(fmt)) {
		fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "/u661f/u671f" : "/u5468") : "") + week[this.getDay() + ""]);
	}
	for (var k in o) {
		if (new RegExp("(" + k + ")").test(fmt)) {
			fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
		}
	}
	return fmt;
};
//+--------------------------------------------------- 
//| 求两个时间的天数差 日期格式为 YYYY-MM-dd 
//+--------------------------------------------------- 
function daysBetween(DateOne, DateTwo) {
	var OneMonth = DateOne.substring(5, DateOne.lastIndexOf('-'));
	var OneDay = DateOne.substring(DateOne.length, DateOne.lastIndexOf('-') + 1);
	var OneYear = DateOne.substring(0, DateOne.indexOf('-'));

	var TwoMonth = DateTwo.substring(5, DateTwo.lastIndexOf('-'));
	var TwoDay = DateTwo.substring(DateTwo.length, DateTwo.lastIndexOf('-') + 1);
	var TwoYear = DateTwo.substring(0, DateTwo.indexOf('-'));
	var cha = ((Date.parse(OneMonth + '/' + OneDay + '/' + OneYear) - Date.parse(TwoMonth + '/' + TwoDay + '/' + TwoYear)) / 86400000);
	return Math.abs(cha);
}
//+--------------------------------------------------- 
//| 日期计算 
//+--------------------------------------------------- 
Date.prototype.DateAdd = function (strInterval, Number) {
	var dtTmp = this;
	switch (strInterval) {
		case 's':
			return new Date(dtTmp.getFullYear(), (dtTmp.getMonth()), dtTmp.getDate(), dtTmp.getHours(), dtTmp.getMinutes(), dtTmp.getSeconds() + Number); //秒 
		case 'n':
			return new Date(dtTmp.getFullYear(), (dtTmp.getMonth()), dtTmp.getDate(), dtTmp.getHours(), dtTmp.getMinutes() + Number, dtTmp.getSeconds()); //分 
		case 'h':
			return new Date(dtTmp.getFullYear(), (dtTmp.getMonth()), dtTmp.getDate(), dtTmp.getHours() + Number, dtTmp.getMinutes(), dtTmp.getSeconds()); //时 
		case 'd':
			return new Date(dtTmp.getFullYear(), (dtTmp.getMonth()), dtTmp.getDate() + Number, dtTmp.getHours(), dtTmp.getMinutes(), dtTmp.getSeconds()); //天 
		case 'w':
			return new Date(dtTmp.getFullYear(), (dtTmp.getMonth()), dtTmp.getDate() + Number * 7, dtTmp.getHours(), dtTmp.getMinutes(), dtTmp.getSeconds()); //周 
		case 'q':
			return new Date(dtTmp.getFullYear(), (dtTmp.getMonth()) + Number * 3, dtTmp.getDate(), dtTmp.getHours(), dtTmp.getMinutes(), dtTmp.getSeconds()); //季度 
		case 'm':
			return new Date(dtTmp.getFullYear(), (dtTmp.getMonth()) + Number, dtTmp.getDate(), dtTmp.getHours(), dtTmp.getMinutes(), dtTmp.getSeconds()); //月 
		case 'y':
			return new Date((dtTmp.getFullYear() + Number), dtTmp.getMonth(), dtTmp.getDate(), dtTmp.getHours(), dtTmp.getMinutes(), dtTmp.getSeconds()); //年 
	}
};
//+--------------------------------------------------- 
//| 比较日期差 dtEnd 格式为日期型或者 有效日期格式字符串 
//+--------------------------------------------------- 
Date.prototype.DateDiff = function (strInterval, dtEnd) {
	var dtStart = this;
	if (typeof dtEnd == 'string') //如果是字符串转换为日期型 
	{
		dtEnd = StringToDate(dtEnd);
	}
	switch (strInterval) {
		case 's':
			return parseInt((dtEnd - dtStart) / 1000);
		case 'n':
			return parseInt((dtEnd - dtStart) / 60000);
		case 'h':
			return parseInt((dtEnd - dtStart) / 3600000);
		case 'd':
			return parseInt((dtEnd - dtStart) / 86400000);
		case 'w':
			return parseInt((dtEnd - dtStart) / (86400000 * 7));
		case 'm':
			return (dtEnd.getMonth() + 1) + ((dtEnd.getFullYear() - dtStart.getFullYear()) * 12) - (dtStart.getMonth() + 1);
		case 'y':
			return dtEnd.getFullYear() - dtStart.getFullYear();
	}
};
//+--------------------------------------------------- 
//| 日期输出字符串，重载了系统的toString方法 
//+--------------------------------------------------- 
Date.prototype.toString = function (showWeek) {
	var myDate = this;
	var str = myDate.toLocaleDateString();
	if (showWeek) {
		var Week = ['日', '一', '二', '三', '四', '五', '六'];
		str += ' 星期' + Week[myDate.getDay()];
	}
	return str;
};
//+--------------------------------------------------- 
//| 日期合法性验证 
//| 格式为：YYYY-MM-DD或YYYY/MM/DD 
//+--------------------------------------------------- 
function IsValidDate(DateStr) {
	var sDate = DateStr.replace(/(^\s+|\s+$)/g, ''); //去两边空格; 
	if (sDate == '') return true;
	//如果格式满足YYYY-(/)MM-(/)DD或YYYY-(/)M-(/)DD或YYYY-(/)M-(/)D或YYYY-(/)MM-(/)D就替换为'' 
	//数据库中，免备案空间，美国服务器，合法日期可以是:YYYY-MM/DD(2003-3/21),数据库会自动转换为YYYY-MM-DD格式 
	var s = sDate.replace(/[\d]{ 4,4 }[\-/]{ 1 }[\d]{ 1,2 }[\-/]{ 1 }[\d]{ 1,2 }/g, '');
	if (s == '') //说明格式满足YYYY-MM-DD或YYYY-M-DD或YYYY-M-D或YYYY-MM-D 
	{
		var t = new Date(sDate.replace(/\-/g, '/'));
		var ar = sDate.split(/[-/:]/);
		if (ar[0] != t.getYear() || ar[1] != t.getMonth() + 1 || ar[2] != t.getDate()) {
			return false;
		}
	} else {
		return false;
	}
	return true;
}
//+--------------------------------------------------- 
//| 日期时间检查 
//| 格式为：YYYY-MM-DD HH:MM:SS 
//+--------------------------------------------------- 
function CheckDateTime(str) {
	var reg = /^(\d+)-(\d{ 1,2 })-(\d{ 1,2 }) (\d{ 1,2 }):(\d{ 1,2 }):(\d{ 1,2 })$/;
	var r = str.match(reg);
	if (r == null) return false;
	r[2] = r[2] - 1;
	var d = new Date(r[1], r[2], r[3], r[4], r[5], r[6]);
	if (d.getFullYear() != r[1]) return false;
	if (d.getMonth() != r[2]) return false;
	if (d.getDate() != r[3]) return false;
	if (d.getHours() != r[4]) return false;
	if (d.getMinutes() != r[5]) return false;
	if (d.getSeconds() != r[6]) return false;
	return true;
}
//+--------------------------------------------------- 
//| 把日期分割成数组 
//+--------------------------------------------------- 
Date.prototype.toArray = function () {
	var myDate = this;
	var myArray = Array();
	myArray[0] = myDate.getFullYear();
	myArray[1] = myDate.getMonth();
	myArray[2] = myDate.getDate();
	myArray[3] = myDate.getHours();
	myArray[4] = myDate.getMinutes();
	myArray[5] = myDate.getSeconds();
	return myArray;
};
//+--------------------------------------------------- 
//| 取得日期数据信息 
//| 参数 interval 表示数据类型 
//| y 年 m月 d日 w星期 ww周 h时 n分 s秒 
//+--------------------------------------------------- 
Date.prototype.DatePart = function (interval) {
	var myDate = this;
	var partStr = '';
	var Week = ['日', '一', '二', '三', '四', '五', '六'];
	switch (interval) {
		case 'y':
			partStr = myDate.getFullYear();
			break;
		case 'm':
			partStr = myDate.getMonth() + 1;
			break;
		case 'd':
			partStr = myDate.getDate();
			break;
		case 'w':
			partStr = Week[myDate.getDay()];
			break;
		case 'ww':
			partStr = myDate.WeekNumOfYear();
			break;
		case 'h':
			partStr = myDate.getHours();
			break;
		case 'n':
			partStr = myDate.getMinutes();
			break;
		case 's':
			partStr = myDate.getSeconds();
			break;
	}
	return partStr;
};
//+--------------------------------------------------- 
//| 取得当前日期所在月的最大天数 
//+--------------------------------------------------- 
Date.prototype.MaxDayOfDate = function () {
	var myDate = this;
	var ary = myDate.toArray();
	var date1 = (new Date(ary[0], ary[1] + 1, 1));
	var date2 = date1.dateAdd(1, 'm', 1);
	var result = dateDiff(date1.Format('yyyy-MM-dd'), date2.Format('yyyy-MM-dd'));
	return result;
};
//+--------------------------------------------------- 
//| 字符串转成日期类型 
//| 格式 MM/dd/YYYY MM-dd-YYYY YYYY/MM/dd YYYY-MM-dd 
//+--------------------------------------------------- 
function dateToString(jsondate, format,nstring) {
    if (jsondate == null || jsondate == "" || jsondate == undefined) {
        if (nstring == undefined || nstring != null || jsondate == "") {
            return "";
        }
        return nstring;
    }
    //jsondate = jsondate.replace("/Date(", "").replace(")/", "");
    //if (jsondate.indexOf("+") > 0) {
    //    jsondate = jsondate.substring(0, jsondate.indexOf("+"));
    //} else if (jsondate.indexOf("-") > 0) {
    //    jsondate = jsondate.substring(0, jsondate.indexOf("-"));
    //}
    var date = new Date(parseInt(jsondate, 10));
    if (format == null || format == "" || format == undefined) {
        format = "yyyy-MM-dd";
    }
    return date.Format(format);
}
//日期转换
function dateConvertSpectialFormat(datestr) {//datestr格式yyyy-MM-dd
    var reportDate = new Date(datestr);
    var currentDate = new Date();
    if (currentDate < reportDate) {
        return reportDate.Format("yyyy-MM-dd HH:mm");

    }
    else if (currentDate.getFullYear() > reportDate.getFullYear()) {
        return reportDate.Format("yyyy-MM-dd HH:mm");
    }
    else if (currentDate.getMonth() > reportDate.getMonth()) {
        return reportDate.Format("MM-dd HH:mm");
    }
    else if (currentDate.getDate() > reportDate.getDate() + 1) {
        return reportDate.Format("MM-dd HH:mm");
    }
    else if (currentDate.getDate() == reportDate.getDate() + 1) {
        return "昨天 " + reportDate.Format("HH:mm");
    }
    else if (currentDate.getDate() == reportDate.getDate()) {
        if (reportDate.getHours() < 12) {
            return "上午 " + reportDate.Format("HH:mm");
        }
        else {
            return "下午 " + reportDate.Format("HH:mm");
        }

    }
    else {
        return reportDate;
    }
}
//后退
function winxinBack(level) {
    var ua = navigator.userAgent.toLowerCase();//获取判断用的对象
    if (ua.indexOf('micromessenger') == -1) {//说明不在微信中
        return false;
    }
    else {
        wx.miniProgram.getEnv(function (res) {
            if (res.miniprogram) {
                wx.miniProgram.navigateBack({
                    delta: level
                });
            }
        })
        return true;
    }
}

function openPage(pageUrl, type) {
    if (type == undefined || type == 0) {
        
            window.location.href = pageUrl;
    }
    else if (type == 1 || type == 2) {
        var device = getLocalCache("device");
        if (device == "miniprogram") {
            miniprogramOpenPage(pageUrl);
            return;
        }
        else if (device == "nomicromessenger") {
            // 走不在小程序的逻辑
            //if (isIOS || type == 2) {
            //    window.open(pageUrl, "_self");
            //} else if (isAndroid) {
            //    window.location.href = pageUrl;
            //} else {
            //    window.location.href = pageUrl;
            //}
            if (type == 2) {
                window.open(pageUrl, "_self");
            } else {
                window.location.href = pageUrl;
            }
        }
        else {
            var ua = navigator.userAgent.toLowerCase();//获取判断用的对象
            if (ua.indexOf('micromessenger') == -1) {//说明不在微信中
                setLocalCache("device", "nomicromessenger");
                // 走不在小程序的逻辑
                //if (isIOS || type == 2) {
                //    window.open(pageUrl, "_self");
                //} else if (isAndroid) {
                //    window.location.href = pageUrl;
                //} else {
                 //   window.location.href = pageUrl;
                // }
                if (type == 2) {
                    window.open(pageUrl, "_self");
                } else {
                    window.location.href = pageUrl;
                }
            }
            else {
                wx.miniProgram.getEnv(function (res) {
                    if (res.miniprogram) {
                        setLocalCache("device", "miniprogram");
                        miniprogramOpenPage(pageUrl);
                    }

                })

            }
        }
    }
}
function miniprogramOpenPage(pageUrl) {

    var miniUrl = "";
    if (pageUrl.indexOf("CombineBuidDetail") > -1) {

        miniUrl = '/pages/report/report?url=';
    }
    else {
        miniUrl = '/pages/webview/webview?url=';
    }
    pageUrl = encodeURIComponent(pageUrl);
    miniUrl = miniUrl + document.location.origin + pageUrl;

    //alert(miniUrl);
    var wxpagestr = getQueryString("wxpage");
    var wxpage = wxpagestr == null ? 0 : wxpagestr;
    if (wxpage < 10) {

        wx.miniProgram.navigateTo({
            url: miniUrl
        });
    }
    else {
        wx.miniProgram.redirectTo({
            url: miniUrl
        });
    }
}
//function openPage(pageUrl) {
//	//if (isIOS) {
//	//	window.open(pageUrl, "_self");
//	//} else if (isAndroid) {
//	//	window.location.href = pageUrl;
//	//} else {
//		window.location.href = pageUrl;
//	//}
//}
//格式化金额
function fmoney(s, n) {
	var fff = "";
	if (s < 0) {
		fff = "-";
		s = s * (-1);
	}
	n = n > 0 && n <= 20 ? n : 2;
	s = parseFloat((s + "").replace(/[^\d\.-]/g, "")).toFixed(n) + "";
	var l = s.split(".")[0].split("").reverse(), r = s.split(".")[1];
	t = "";
	for (i = 0; i < l.length; i++) {
		t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? "," : "");
	}
	return fff + t.split("").reverse().join("") + "." + r;
}

//使用本地缓存
function setSessionCache(key, value) {
    sessionStorage[key.toLowerCase()] = value;
}
function getSessionCache(key) {
    return sessionStorage[key.toLowerCase()];
}

//使用本地缓存
function setLocalCache(key, value) {
    localStorage[key.toLowerCase()] =  value;
}
function getLocalCache(key) {
    return localStorage[key.toLowerCase()];
}
//cookie过期时间-7天*100
window.cookieExpires = 7 * 100;

function setCookie(key, value) {
	$.cookie(key, value, { expires: window.cookieExpires, path: '/' });
}
function setCookieWithExpires(key, value, expires) {
    $.cookie(key, value, { expires: expires, path: '/' });
}
//移除
function removeCookie(key) {
	$.cookie(key, null);
}

function getCookie(key) {
	var cookie = $.cookie(key);
	if (!cookie || cookie == 0) {
		return "";
	} else {
		return cookie;
	}
}
//验证email的合法性  
function is_email(email) {
	if (! /^[\w\-\.]+@[\w\-\.]+(\.\w+)+$/.test(email)) {
		return false;
	}
	return true;
}
function isNumber(value) {
    var patrn = /^(-)?\d+(\.\d+)?$/;
    if (patrn.exec(value) == null || value == "") {
        return false
    } else {
        return true
    }
}
//数字、字母、汉字
function isCharChineNumber(value) {
    var patrn = /^[A-Za-z0-9\u4e00-\u9fa5]+$/gi;
    if (patrn.test(value)) {
        return true
    } else {
        return false
    }
}
function checkFloatNum(str) {
    var reg_zs = /^([1-9][0-9]*|0)(\.[0-9]+)*$/i;
    if (!reg_zs.test(str)) {
        return false;
    }
    return true;

}
function confirmPwd(obj,str,errorObj) {
    var pwd =obj.val();
    if (isNullOrEmpty(pwd)) {
        $(errorObj).html(str + "不能为空！");
        return false;
    } else {
        $(errorObj).html("");
    }

    var reg = /^(?!^\d+$)(?!^[a-zA-Z]+$)[0-9a-zA-Z]{8,20}$/;
    if (!reg.test(pwd)) {
        if (errorObj != 'undefined')
            $(errorObj).html("请输入8-20位数字+字母");
        return false;
    } else {
        if (errorObj != 'undefined')
            $(errorObj).html("");
    }
    return true;
}


//function initInputType(id) {
//    if (isIOS) {
//        document.getElementById(id).type = "number";
//    } else {
//        document.getElementById(id).type = "tel";
//    }
//}
function ToStringP2(v) {
    if (v != null && v != "") {
        return (v * 100).toFixed(2) + "%";
    } else {
        return '--';
    }
}
//精度丢失问题
//乘法
function accMul(arg1, arg2) {
    var m = 0, s1 = arg1.toString(), s2 = arg2.toString();
    try { m += s1.split(".")[1].length } catch (e) { }
    try { m += s2.split(".")[1].length } catch (e) { }
    return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m)
}
//加法
function add(num1, num2) {
    var r1, r2, m, n;
    try { r1 = num1.toString().split(".")[1].length } catch (e) { r1 = 0 }
    try { r2 = num2.toString().split(".")[1].length } catch (e) { r2 = 0 }
    m = Math.pow(10, Math.max(r1, r2));
    n = (r1 >= r2) ? r1 : r2;
    return Number(((num1 * m + num2 * m) / m).toFixed(n));
}
//千位分隔符
function thousandBitSeparator(num) {
    var re = /(?=(?!\b)(\d{3})+$)/g;
    return num.toString().replace(re, ',');
}
//$(function () {
//    if (isIOS) {
//        $(document).on('touchend', function () {
//            var e = window.event || e;
//            if (!$(e.target).is("input,select")) {
//                document.activeElement.blur();
//            }
//        });
//    }
//});
function JsonString(data) {
    var str = JSON.stringify(data);
    return encodeURIComponent(str);
}
function JsonParseString(data) {
    var model = JSON.parse(decodeURIComponent( data));
    return model;
}



function Exit() {
   
    removeCookie("manange_token");
    setLocalCache("manange_name","");
    removeCookie("manange_id");
    //window.parent.location.href = "login.html";
    //var loginPage = getCookie("loginPage");
    //if (isNullOrEmpty(loginPage)) {
    //    window.parent.location.href = "login.html";
    //}
    //else{
    //    window.parent.location.href = loginPage;
    //}
    //layer.prompt({
    //    value: '',
    //    title: '请填写退出日志',
    //    yes: function (index, layero) {
    //        var val = layero.find(".layui-layer-input").val();
    //        if (val.gblen() > 50) {
    //            layer.alert("输入长度最大只能是50位");
    //            return;
    //        }

    //        $.postJson("LoginLog/updateLoginLog", JSON.stringify({ pageIndex: 0, pageSize: 10000, content: val }), function(d) {

    //                if (d.code > 0) {
    //                    removeCookie("navtionList");
    //                    removeCookie("userName");
    //                    removeCookie("userRole");
    //                    removeCookie("token");
    //                    window.parent.location.href = "login.html";
    //                    layer.close(index);
    //                    return;
    //                } else {
    //                    layer.alert("退出异常");
    //                }
    //            }, null, null, getSessionCache("token")
    //        );


    //    }
    //});

    
}

$.fn.extend({
    JsonData: function (dataname, data) {
        var name = "data-" + dataname;
        if (data==undefined) {
            var str = $(this).attr(name);
            return JSON.parse(decodeURIComponent(str));
        }
        else {
            $(this).attr(name, encodeURIComponent(JSON.stringify(data)));
        }
    },
    myHide: function (speed) {
        if ($(this).length>10) {
            $(this).css("display","none");
        }
        else {
            $(this).hide(speed);
        }
    }
    ,
    myShow: function (speed) {
        if ($(this).length > 10) {
            $(this).css("display", "");
        }
        else {
            $(this).show(speed);
        }
    }
});
//全部替换
String.prototype.myReplace = function (f, e) {//吧f替换成e
    //var reg = new RegExp(f, "g"); //创建正则RegExp对象  
    var result = this;
    for (var i = 0; i < this.length; i++) {
        result=result.replace(f, e);
    }
    return result;
}
//检验区块和字段是否是关键字标点符号等
//区块和字段的输入检验
var kewords = [
"break",
"case",
"catch",
"continue",
"default",
"delete",
"do",
"else",
"finally",
"for",
"function",
"if",
"in",
"instanceof",
"new",
"return",
"switch",
"this",
"throw",
"try",
"typeof",
"var",
"void",
"while",
"with",
"true",
"false",
"null"
];

function myCheckInput(msg,isHead) {
    if (msg == null || $.trim(msg).length == 0) {
        myalert("不能为空");
        return false;
    }
    if (msg.length > 100) {
        myalert("名字长度不能大于100");
        return false;
    }
    msg = $.trim(msg);
    var reg = /[\u3002|\uff1f|\uff01|\uff0c|\u3001|\uff1b|\uff1a|\u201c|\u201d|\u2018|\u2019|\uff08|\uff09|\u300a|\u300b|\u3008|\u3009|\u3010|\u3011|\u300e|\u300f|\u300c|\u300d|\ufe43|\ufe44|\u3014|\u3015|\u2026|\u2014|\uff5e|\ufe4f|\uffe5]/;

    var english = /[a-z]/i;
    var canCharHeadArray = [];
    if (isHead != undefined && isHead != null && isHead) {
        if (canCharHeadArray.indexOf(msg[0]) == -1 && !english.test(msg[0])) {
            if (!isNaN(msg[0]) || reg.test(msg[0]) || msg.charCodeAt(i) <= 255) {
                myalert("必须以中文、英文开头");
                return false;
            }

        }
    }
    if (msg.indexOf(" ") > -1) {
        myalert("不能包含空格");
        return false;
    }
    var validc = ["(", ")", "_", "$"];

    for (var i = 0; i < msg.length; i++) {
        var m = msg[i];
        if (msg.charCodeAt(i) <= 255 && !english.test(m)) {
            var isCan = validc.indexOf(m) > -1 || !isNaN(m) ? true : false;
            if (!isCan) {
                myalert("不能包含" + m.myReplace("\"", "&quot;"));
                return false;
            }

        }
        else if (reg.test(m)) {
            myalert("不能包含" + m.myReplace("\"", "&quot;"));
            return false;
        }
    }
    for (var i = 0; i < kewords.length; i++) {
        var k = kewords[i];
        if (msg == k) {
            myalert("不能是" + msg.myReplace("\"", "&quot;") + "关键字");
            return false;
        }
    }
    return true;
}
//验证email的合法性  
function is_email(email) {
	if (! /^[\w\-\.]+@[\w\-\.]+(\.\w+)+$/.test(email)) {
		return false;
	}
	return true;
}
function isNumber(value) {
    var patrn = /^(-)?\d+(\.\d+)?$/;
    if (patrn.exec(value) == null || value == "") {
        return false
    } else {
        return true
    }
}
function checkFloatNum(str) {
    var reg_zs = /^([1-9][0-9]*|0)(\.[0-9]+)*$/i;
    if (!reg_zs.test(str)) {
        return false;
    }
    return true;

}

function initInputType(id) {
    
document.getElementById(id).type = "tel";
    
}
function ifEmptyNull(data,d) {
    if (data == null) {
        if (d != undefined) {
            return d;
        }
        return "";
    }
    else {
        return data;
    }
}