﻿$(function () {
    if (getCookie("manange_token") == "" || getCookie("manange_token") == "null" || getCookie("manange_token") == undefined || getCookie("manange_token") == null) {
        window.parent.location.href = "/manage/login.html";
    }
})