package com.yili.datagrabber;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.yili.bean.ParamSearch;
import com.yili.bean.ResultData;
import com.yili.services.IShortService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DataGrabberApplicationTests {

	@Autowired
	private IShortService shortService;
	
	@Test
	public void contextLoads() {
		ParamSearch param = new ParamSearch();
		param.setKeyWord("https://zhangvalue.blog.csdn.net/");
		ResultData<String>  test = shortService.getShortDomain(param);
		System.out.println(test.getData());
		//shortService.getDomainUrl(key)
	}

}
